﻿
Application created to test methods of encryption/decryption.  The intent was to determine best options to incorporate encryption/decryption of user names, passwords, and other 
sensitive data in configuration files and in the database.