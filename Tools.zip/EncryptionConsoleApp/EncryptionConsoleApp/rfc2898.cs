﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace EncryptionConsoleApp
{
	public static class rfc2898
	{
		#region RijndaelManaged
		public static string EncryptString(string sPswd, string sSaltKey, int iSaltLength, string sIVKey, string sInputString)
		{
			RijndaelManaged rmAlg = new RijndaelManaged();
			rmAlg.BlockSize = 256;
			rmAlg.Key = Encoding.ASCII.GetBytes(sSaltKey);
			rmAlg.IV = Encoding.ASCII.GetBytes(sIVKey);
			rmAlg.Padding = PaddingMode.PKCS7;
			rmAlg.Mode = CipherMode.CBC;


			var encryptor = rmAlg.CreateEncryptor(rmAlg.Key, rmAlg.IV);

			byte[] cipherTextBytes;

			using (var memoryStream = new MemoryStream())
			{
				using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
				{
					using (StreamWriter strmWriter = new StreamWriter(cryptoStream))
					{
						strmWriter.Write(sInputString);
						strmWriter.Close();
					}

					cipherTextBytes = memoryStream.ToArray();
					cryptoStream.Close();
				}
				memoryStream.Close();
			}

			return Convert.ToBase64String(cipherTextBytes);
		}

		public static string DecryptString(string sPswd, string sSaltKey, int iSaltLength, string sIVKey, string sInputStringE)
		{
			byte[] cipherTextBytes;
			try
			{
				cipherTextBytes = Convert.FromBase64String(sInputStringE);
			}
			catch (Exception ex)
			{
				//not encrypted string - return
				return string.Format("{0}  [{1}]", sInputStringE, ex.Message);
			}

			RijndaelManaged rmAlg = new RijndaelManaged();
			rmAlg.BlockSize = 256;
			rmAlg.Key = Encoding.ASCII.GetBytes(sSaltKey);
			rmAlg.IV = Encoding.ASCII.GetBytes(sIVKey);
			rmAlg.Padding = PaddingMode.PKCS7;
			rmAlg.Mode = CipherMode.CBC;

			var decryptor = rmAlg.CreateDecryptor(rmAlg.Key, rmAlg.IV);
			string sDecrypted = "";

			using (var memoryStream = new MemoryStream(cipherTextBytes))
			{
				using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
				{
					using (StreamReader strmWriter = new StreamReader(cryptoStream))
					{
						sDecrypted = strmWriter.ReadToEnd();
						strmWriter.Close();
					}

					cryptoStream.Close();
				}
				memoryStream.Close();
			}

			//return Encoding.UTF8.GetString(cipherTextBytes, 0, cipherTextBytes.Length).TrimEnd("\0".ToCharArray());

			//if (sDecrypted.IndexOf("EEncrypt") == 0) return sDecrypted.Substring(10);

			return sDecrypted;
		}
		#endregion

		#region AES
		//public static string EncryptString(string sPswd, string sSaltKey, int iSaltLength, string sIVKey, string sInputString)
		//{
		//	//int iIterations = 10000;
		//	//string sModString = string.Format("{0}{1}", "EEncrypted", sInputString);
		//	//byte[] bKeyBytes = new Rfc2898DeriveBytes(sPswd, Encoding.ASCII.GetBytes(sSaltKey), iIterations).GetBytes(iSaltLength / 8);


		//	AesManaged aesAlg = new AesManaged();
		//	aesAlg.BlockSize = 128;
		//	aesAlg.Key = Encoding.ASCII.GetBytes(sSaltKey); //ASCIIEncoding.UTF8.GetBytes(sSaltKey); //Encoding.ASCII.GetBytes(sSaltKey);
		//	aesAlg.IV = Encoding.ASCII.GetBytes(sIVKey); //ASCIIEncoding.UTF8.GetBytes(sIVKey); //Encoding.ASCII.GetBytes(sIVKey);
		//	aesAlg.Padding = PaddingMode.PKCS7;
		//	aesAlg.Mode = CipherMode.CBC;

		//	var encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

		//	byte[] cipherTextBytes;

		//	using (var memoryStream = new MemoryStream())
		//	{
		//		using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
		//		{
		//			using (StreamWriter strmWriter = new StreamWriter(cryptoStream))
		//			{
		//				strmWriter.Write(sInputString);
		//				strmWriter.Close();
		//			}

		//			cipherTextBytes = memoryStream.ToArray();
		//			cryptoStream.Close();
		//		}
		//		memoryStream.Close();
		//	}

		//	return Convert.ToBase64String(cipherTextBytes);
		//}

		//public static string DecryptString(string sPswd, string sSaltKey, int iSaltLength, string sIVKey, string sInputStringE)
		//{
		//	int iIterations = 10000;
		//	byte[] cipherTextBytes;
		//	try
		//	{
		//		cipherTextBytes = Convert.FromBase64String(sInputStringE);
		//	}
		//	catch (Exception ex)
		//	{
		//		//not encrypted string - return

		//		return string.Format("{0}  [{1}]", sInputStringE, ex.Message);
		//		//return sInputStringE;
		//	}


		//	//byte[] bFlag = new byte[10];
		//	//Buffer.BlockCopy(cipherTextBytes, 0, bFlag, 0, 10);

		//	byte[] bKeyBytes = new Rfc2898DeriveBytes(sPswd, Encoding.ASCII.GetBytes(sSaltKey), iIterations).GetBytes(iSaltLength / 8);

		//	AesManaged aesAlg = new AesManaged();
		//	aesAlg.Key = bKeyBytes;
		//	aesAlg.IV = Encoding.ASCII.GetBytes(sIVKey);
		//	aesAlg.Padding = PaddingMode.PKCS7;
		//	aesAlg.Mode = CipherMode.CBC;

		//	var decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
		//	string sDecrypted = "";

		//	using (var memoryStream = new MemoryStream(cipherTextBytes))
		//	{
		//		using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
		//		{
		//			using (StreamReader strmWriter = new StreamReader(cryptoStream))
		//			{
		//				sDecrypted = strmWriter.ReadToEnd();
		//				strmWriter.Close();
		//			}

		//			cryptoStream.Close();
		//		}
		//		memoryStream.Close();
		//	}

		//	//return Encoding.UTF8.GetString(cipherTextBytes, 0, cipherTextBytes.Length).TrimEnd("\0".ToCharArray());

		//	if (sDecrypted.IndexOf("EEncrypt") == 0) return sDecrypted.Substring(10);

		//	return sDecrypted;
		//}
		#endregion


		#region RFC with AES
		//public static string EncryptString(string sPswd, string sSaltKey, int iSaltLength, string sIVKey, string sInputString)
		//{
		//	int iIterations = 10000;
		//	//byte[] bPre = Encoding.UTF8.GetBytes("EEncrypted");
		//	//byte[] bBytes = Encoding.UTF8.GetBytes(sInputString);

		//	string sModString = string.Format("{0}{1}", "EEncrypted", sInputString);
		//	byte[] bKeyBytes = new Rfc2898DeriveBytes(sPswd, Encoding.ASCII.GetBytes(sSaltKey), iIterations).GetBytes(iSaltLength / 8);
			
		//	AesManaged aesAlg = new AesManaged();
		//	aesAlg.Key = bKeyBytes;
		//	aesAlg.IV = Encoding.ASCII.GetBytes(sIVKey);
		//	aesAlg.Padding = PaddingMode.PKCS7;
		//	aesAlg.Mode = CipherMode.CBC;

		//	var encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

		//	byte[] cipherTextBytes;

		//	using (var memoryStream = new MemoryStream())
		//	{
		//		using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
		//		{
		//			using (StreamWriter strmWriter = new StreamWriter(cryptoStream))
		//			{
		//				strmWriter.Write(sModString);
		//				strmWriter.Close();
		//			}

		//			cipherTextBytes = memoryStream.ToArray();
		//			cryptoStream.Close();
		//		}
		//		memoryStream.Close();
		//	}

		//	return Convert.ToBase64String(cipherTextBytes);
		//}

		//public static string DecryptString(string sPswd, string sSaltKey, int iSaltLength, string sIVKey, string sInputStringE)
		//{
		//	int iIterations = 10000;
		//	byte[] cipherTextBytes;
		//	try
		//	{
		//		cipherTextBytes = Convert.FromBase64String(sInputStringE);
		//	}
		//	catch (Exception ex)
		//	{ 
		//		//not encrypted string - return

		//		return string.Format("{0}  [{1}]", sInputStringE, ex.Message);
		//		//return sInputStringE;
		//	}
			
			
		//	//byte[] bFlag = new byte[10];
		//	//Buffer.BlockCopy(cipherTextBytes, 0, bFlag, 0, 10);

		//	byte[] bKeyBytes = new Rfc2898DeriveBytes(sPswd, Encoding.ASCII.GetBytes(sSaltKey), iIterations).GetBytes(iSaltLength / 8);

		//	AesManaged aesAlg = new AesManaged();
		//	aesAlg.Key = bKeyBytes;
		//	aesAlg.IV = Encoding.ASCII.GetBytes(sIVKey);
		//	aesAlg.Padding = PaddingMode.PKCS7;
		//	aesAlg.Mode = CipherMode.CBC;

		//	var decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
		//	string sDecrypted = "";

		//	using (var memoryStream = new MemoryStream(cipherTextBytes))
		//	{
		//		using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
		//		{
		//			using (StreamReader strmWriter = new StreamReader(cryptoStream))
		//			{
		//				sDecrypted = strmWriter.ReadToEnd();
		//				strmWriter.Close();
		//			}

		//			cryptoStream.Close();
		//		}
		//		memoryStream.Close();
		//	}

		//	//return Encoding.UTF8.GetString(cipherTextBytes, 0, cipherTextBytes.Length).TrimEnd("\0".ToCharArray());

		//	if (sDecrypted.IndexOf("EEncrypt") == 0) return sDecrypted.Substring(10);
				
		//	return sDecrypted;
		//}
		#endregion

		#region RFC with RijndaelManaged
		//public static string EncryptString(string sPswd, string sSaltKey, int iSaltLength, string sIVKey, string sInputString)
		//{
		//	int iIterations = 10000;
		//	byte[] bBytes = Encoding.UTF8.GetBytes(sInputString);

		//	byte[] bKeyBytes = new Rfc2898DeriveBytes(sPswd, Encoding.ASCII.GetBytes(sSaltKey), iIterations).GetBytes(iSaltLength / 8);
		//	var symmetricKey = new RijndaelManaged() { Mode = CipherMode.CBC, Padding = PaddingMode.PKCS7 };
		//	var encryptor = symmetricKey.CreateEncryptor(bKeyBytes, Encoding.ASCII.GetBytes(sIVKey));

		//	byte[] cipherTextBytes;

		//	using (var memoryStream = new MemoryStream())
		//	{
		//		using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
		//		{
		//			cryptoStream.Write(bBytes, 0, bBytes.Length);
		//			cryptoStream.FlushFinalBlock();
		//			cipherTextBytes = memoryStream.ToArray();
		//			cryptoStream.Close();
		//		}
		//		memoryStream.Close();
		//	}
		//	return Convert.ToBase64String(cipherTextBytes);
		//}

		//public static string DecryptString(string sPswd, string sSaltKey, int iSaltLength, string sIVKey, string sInputStringE)
		//{
		//	int iIterations = 10000;
		//	byte[] cipherTextBytes = Convert.FromBase64String(sInputStringE);
		//	byte[] keyBytes = new Rfc2898DeriveBytes(sPswd, Encoding.ASCII.GetBytes(sSaltKey), iIterations).GetBytes(iSaltLength / 8);
		//	var symmetricKey = new RijndaelManaged() { Mode = CipherMode.CBC, Padding = PaddingMode.PKCS7 };

		//	var decryptor = symmetricKey.CreateDecryptor(keyBytes, Encoding.ASCII.GetBytes(sIVKey));
		//	var memoryStream = new MemoryStream(cipherTextBytes);
		//	var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
		//	byte[] plainTextBytes = new byte[cipherTextBytes.Length];

		//	int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
		//	memoryStream.Close();
		//	cryptoStream.Close();

		//	return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount).TrimEnd("\0".ToCharArray());
		//}
		#endregion

		#region RFC with TripleDES
		//public static string EncryptString(string sPswd, int iSaltLength, string sInputString)
		//{
		//	int iIterations = 10000;

		//	try
		//	{
		//		Rfc2898DeriveBytes rKey1 = new Rfc2898DeriveBytes(sPswd, iSaltLength, iIterations);

		//		// Encrypt the data.
		//		TripleDES tAlgorhythm = TripleDES.Create();
		//		tAlgorhythm.Key = rKey1.GetBytes(iSaltLength);
				
		//		MemoryStream memEncryptStream = new MemoryStream();
		//		CryptoStream crypEncryptStream = new CryptoStream(memEncryptStream, tAlgorhythm.CreateEncryptor(), CryptoStreamMode.Write);

		//		byte[] bBytes = new System.Text.UTF8Encoding(false).GetBytes(sInputString);

		//		crypEncryptStream.Write(bBytes, 0, bBytes.Length);
		//		crypEncryptStream.FlushFinalBlock();
		//		crypEncryptStream.Close();

		//		rKey1.Reset();
		//		return Convert.ToBase64String(memEncryptStream.ToArray());
		//	}
		//	catch (Exception ex)
		//	{
		//		throw new Exception(string.Format("Error:  {0} [{1}]", ex.Message, ex.InnerException.Message));
		//		//return "";
		//	}
		//}

		//public static string DecryptString(string sPswd, int iSaltLength, string sInputString)
		//{
		//	int iIterations = 10000;

		//	try
		//	{
		//		Rfc2898DeriveBytes rKeyE = new Rfc2898DeriveBytes(sPswd, iSaltLength, iIterations);
		//		Rfc2898DeriveBytes rKey1 = new Rfc2898DeriveBytes(sPswd, iSaltLength);

		//		// Recreate encryption key
		//		TripleDES tAlgorhythmE = TripleDES.Create();
		//		tAlgorhythmE.Key = rKeyE.GetBytes(iSaltLength);

		//		// Decrypt the data.
		//		TripleDES tAlgorhythm = TripleDES.Create();
		//		tAlgorhythm.Key = rKey1.GetBytes(iSaltLength);
		//		tAlgorhythm.IV = tAlgorhythmE.IV;

		//		MemoryStream memDecryptStream = new MemoryStream();
		//		CryptoStream crypDecryptStream = new CryptoStream(memDecryptStream, tAlgorhythm.CreateDecryptor(), CryptoStreamMode.Write);
				
		//		byte[] bBytes = Convert.FromBase64String(sInputString);

		//		crypDecryptStream.Write(bBytes, 0, bBytes.Length);
		//		crypDecryptStream.Flush();
		//		crypDecryptStream.Close();


		//		rKeyE.Reset();
		//		rKey1.Reset();
		//		return Convert.ToBase64String(memDecryptStream.ToArray());
		//	}
		//	catch (Exception ex)
		//	{
		//		throw new Exception(string.Format("Error:  {0} [{1}]", ex.Message, ex.InnerException.Message));

		//	}
		//}
		#endregion
	}
}
