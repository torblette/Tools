﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EncryptionConsoleApp
{
	class Program
	{
		static void Main(string[] args)
		{
			string sPassword = "ThisIsaT3st"; //password would be from config
			//string sSalt = "S4lt!th1S#c0dE"; //Salt would be from hard coding in class
			////string sIV = "1234567890123456"; //initialization vector would be from database table (name it salt in DB)
			//string sIV =   "1a2B3c4D5e6f7G8H"; //initialization vector would be from database table (name it salt in DB)

			//RijndaelManaged
				string sSalt = "S4lt!th1S#c0dE56"; //Salt would be from hard coding in class
				string sIV = "1a2B3c4D5e6f7G8H1a2B3c4D5e6f7G8H"; //initialization vector would be from database table (name it salt in DB)
				string sEncryptedString = rfc2898.EncryptString(sPassword, sSalt, 256, sIV, "SERVER=Server060;DATABASE=MYTESTDATABASE;UID=TestAppUser;PWD=passWord123;");
				Console.WriteLine(string.Format(" "));
				Console.WriteLine(string.Format("Encrypted string: {0}", sEncryptedString));
				string sDecryptedString = rfc2898.DecryptString(sPassword, sSalt, 256, sIV, sEncryptedString);
				Console.WriteLine(string.Format(" "));
				Console.WriteLine(string.Format("Decrypted string: {0}", sDecryptedString));

				//Console.WriteLine(string.Format(" "));
				//Console.WriteLine(string.Format(" "));
				//Console.WriteLine(string.Format("date: {0}", System.DateTime.Now.ToString("u")));
				//Console.WriteLine(string.Format("date: {0}", System.DateTime.Now.ToString("o")));
				//Console.WriteLine(string.Format("date: {0}Z", System.DateTime.Now.ToString("s")));
				//Console.WriteLine(string.Format("date: {0}Z", System.DateTime.Now.ToUniversalTime().ToString("s")));
				//Console.WriteLine(string.Format("date: {0}", System.DateTime.Now.AddDays(1).ToString("yyyyMMdd")));
				

			//AES
				//string sSalt = "S4lt!th1S#c0dE56"; //Salt would be from hard coding in class
				//string sIV = "1a2B3c4D5e6f7G8H"; //initialization vector would be from database internals table (name it salt in DB)
				//string sEncryptedString = rfc2898.EncryptString(sPassword, sSalt, 256, sIV, "Powell");
				//Console.WriteLine(string.Format("Encrypted string: {0}", sEncryptedString));
				//string sDecryptedString = rfc2898.DecryptString(sPassword, sSalt, 256, sIV, "7/dVaaTOHVEdphWWwGdF7g==");
				//Console.WriteLine(string.Format("Decrypted string: {0}", sDecryptedString));

			//RFC Derived bytes and AES
				////string sEncryptedString = rfc2898.EncryptString(sPassword, sSalt, 256, sIV, "MyTest String is a PAIN!");
				//string sEncryptedString = rfc2898.EncryptString(sPassword, sSalt, 256, sIV, "Test02");
				//Console.WriteLine(string.Format("Encrypted string: {0}", sEncryptedString));

				//string sDecryptedString;
				//sDecryptedString = rfc2898.DecryptString(sPassword, sSalt, 256, sIV, "ItYQlLzlmMVkuk0WKqyea0ldsa1tARxd4Hbk8y7r8+U=");
				// Console.WriteLine(string.Format("Decrypted string: {0}", sDecryptedString));
				// //sDecryptedString = rfc2898.DecryptString(sPassword, sSalt, 256, sIV, "MyTest String is a PAIN!");
				// //Console.WriteLine(string.Format("Decrypted string: {0}", sDecryptedString));

			//RFC and RijndaelManaged
				//string sEncryptedString = rfc2898.EncryptString(sPassword, sSalt, 256, sIV, "Powell");
				//Console.WriteLine(string.Format("Encrypted string: {0}", sEncryptedString));
				//string sDecryptedString = rfc2898.DecryptString(sPassword, sSalt, 256, sIV, "7/dVaaTOHVEdphWWwGdF7g==");
				//Console.WriteLine(string.Format("Decrypted string: {0}", sDecryptedString));

			//TripleDES
				//string sEncryptedString = rfc2898.EncryptString(sPassword, 64, "MyTest String is a PAIN!");
				//Console.WriteLine(string.Format("Encrypted string: {0}", sEncryptedString));
				//string sDecryptedString = rfc2898.DecryptString(sPassword, 16, sEncryptedString);
				//Console.WriteLine(string.Format("Decrypted string: {0}", sDecryptedString));


			//System.Threading.Thread.Sleep(30000);
            Console.ReadKey();
        }
	}
}
