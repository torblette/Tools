﻿
Update the app.config file for target database

Update the "vPath" variable in the Program.cs file for the target directory of the flat file

Application dumps table data to a flat file. Its proven useful for quick data searches on smaller databases.