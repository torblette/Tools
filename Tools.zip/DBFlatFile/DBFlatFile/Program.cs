﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace DBFlatFile
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var sConn = ConfigurationManager.AppSettings["sqlConnection"];
                StringBuilder sbRow = new StringBuilder();
                var vPath = @"C:\zProjects\SQLServerLocal\FlatFiles\dbFile_z_FlatFile.txt";

                SqlConnection sqlConn = new SqlConnection(sConn);
                SqlCommand sqlCmd = new SqlCommand("SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME", sqlConn);
                DataTable dTableNames = new DataTable();

                sqlConn.Open();
                dTableNames.Load(sqlCmd.ExecuteReader());

                foreach (DataRow dRow in dTableNames.Rows)
                {
                    Console.WriteLine(dRow["TABLE_NAME"].ToString());

                    if (!File.Exists(vPath))
                    {
                        File.Create(vPath).Close();
                    }

                    //Write table name
                    sbRow.AppendLine(dRow["TABLE_NAME"].ToString());
                    sbRow.AppendLine("================================================================");
                    TextWriter tWriteTable = new StreamWriter(vPath, true);
                    tWriteTable.WriteLine(sbRow.ToString());
                    tWriteTable.Close();
                    sbRow.Clear();

                    DataTable dData = new DataTable();
                    sqlCmd = new SqlCommand(string.Format("SELECT * FROM {0}", dRow["TABLE_NAME"].ToString()), sqlConn);
                    dData.Load(sqlCmd.ExecuteReader());

                    IEnumerable<string> columnNames = dData.Columns.Cast<DataColumn>().Select(column => column.ColumnName);
                    sbRow.AppendLine(string.Join("\t", columnNames));

                    //Write table column headers
                    TextWriter tWriteCol = new StreamWriter(vPath, true);
                    tWriteCol.WriteLine(sbRow.ToString());
                    tWriteCol.Close();
                    sbRow.Clear();

                    //Get data
                    foreach (DataRow dRowData in dData.Rows)
                    {
                        IEnumerable<string> fields = dRowData.ItemArray.Select(field => field.ToString());
                        sbRow.AppendLine(string.Join("\t\t", fields));
                    }

                    //Write table data 
                    TextWriter tWriteData = new StreamWriter(vPath, true);
                    tWriteData.WriteLine(sbRow.ToString());
                    tWriteData.Close();
                    sbRow.Clear();
                }

                sqlConn.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("EXCEPTION [{0}]", ex.Message));
            }
            finally
            {
                Console.WriteLine("Completed - Press any key to close");
                Console.ReadKey();
            }
        }
    }
}
